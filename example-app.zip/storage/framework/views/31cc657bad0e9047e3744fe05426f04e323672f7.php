
<?php $__env->startSection('section'); ?>
    <div>
        <div>
            <div>
                <h1>Page masih dalam pengembangan</h1>
                <div style="height: 110px"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/shopmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jevon\example-app\resources\views/fish/Lain.blade.php ENDPATH**/ ?>