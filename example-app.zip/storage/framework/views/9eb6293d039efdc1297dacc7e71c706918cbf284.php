
<?php $__env->startSection('section'); ?>
    <div class="about-container">
        <div class="about-content">
            <h1>About Java Goldfish</h1>
            <div class="text-about">
                <h2 style="font-size: 32px; text-align: left;">
                    Background Java Goldfish
                </h2>
                <p class="hammerfont">
                    Berawal dari hobi memelihara ikan mas koki. 
                    Saya bernama edy santoso yang berdomisili di 
                    kota Biltar, kabupaten blitar, propinsi jawa timur, 
                    negara indonesia, Melihat sangat indahnya ikan mas
                    koki dengan berbagai jenis bentuk dan corak warna ikan mas
                    koki, menjadikan ikan mas koki sangat indah dipandang untuk
                    di pelihara 
                </p>
                <br>
                <h2>
                    Varian ikan mas koki yang banyak diminati:
                </h2>
                <p>
                    1. Oranda<br>
                    2. Ranchu<br>
                    3. Ryukin<br>
                    4. Demekin<br><br>
                    Dan masih banyak varian ikan mas koki lainnya 
                    Oleh karenanya.. kami hadir di sini untuk memberikan dan berbagi keindahan dalam menyediakan ikan mas koki yang berkualiatas dan sehat dengan harga terjangkau 
                    Kami juga dapat mengirimkan ikan mas koki ke seluruh daerah di indonesia 
                    Semoga dengan kehadiran kami dapat menambah koleksi ikan mas koki di aquarium anda pecinta dan penggemar ikan mas koki
                    <br><br>
                    Salam,
                    Javagoldfish
                </p>
                <a href="/Ketentuan">Ketentuan Java Goldfish</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/shopmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jevon\example-app\resources\views/misc/about.blade.php ENDPATH**/ ?>