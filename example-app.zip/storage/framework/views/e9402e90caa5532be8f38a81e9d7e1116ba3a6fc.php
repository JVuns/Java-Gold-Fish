
<?php $__env->startSection('section'); ?>
    <div>
        <h1>Filter</h1>
        <script src="JS/browse.js">
        </script>   
        <select name="types" id="fishTypes" list="Fish types">
            <option value="default" selected="selected">Fish types--</option>
            <option value="saab">Saab</option>
            <option value="opel">Opel</option>
            <option value="audi">Audi</option>
        </select>
        <select name="filter" id="fishFilter" list="Filter by">
            <option value="default" selected="selected">Filter by--</option>
            <option value="volvo">Date</option>
            <option value="saab">Name</option>
            <option value="opel">Price</option>
            <option value="audi">Time Post</option>
        </select>
        <button>Go</button>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jevon\example-app\resources\views/fish/browse.blade.php ENDPATH**/ ?>