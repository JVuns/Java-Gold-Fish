
<?php $__env->startSection('section'); ?>
<div class="content-container">
    <div>
        <h1>Ryukin</h1>
        <div style="height: 110px;">
            <h2 style="padding-left: 20px">No Entry</h2>
        </div>
    </div>
    <div class="products-container">
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/shopmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jevon\example-app\resources\views/fish/Ryukin.blade.php ENDPATH**/ ?>