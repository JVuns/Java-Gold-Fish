
<?php $__env->startSection('section'); ?>
    <div class="content-container">
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/shopmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jevon\example-app\resources\views/misc/contact.blade.php ENDPATH**/ ?>