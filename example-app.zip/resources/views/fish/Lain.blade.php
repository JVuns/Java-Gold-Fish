@extends('layouts/shopmenu')
@section('section')
    <div>
        <div>
            <div>
                <h1>Page masih dalam pengembangan</h1>
                <div style="height: 110px"></div>
            </div>
        </div>
    </div>
@endsection