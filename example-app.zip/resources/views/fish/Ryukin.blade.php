@extends('layouts/shopmenu')
@section('section')
<div class="content-container">
    <div>
        <h1>Ryukin</h1>
        <div style="height: 110px;">
            <h2 style="padding-left: 20px">No Entry</h2>
        </div>
    </div>
    <div class="products-container">
    </div>
</div>
@endsection