@extends('layouts/shopmenu')
@section('section')
    <div class="content-container">
        
    </div>
@endsection